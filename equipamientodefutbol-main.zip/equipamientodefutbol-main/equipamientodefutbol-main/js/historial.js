
window.onload = function() {
    var pedidos = JSON.parse(localStorage.getItem("pedidos")) || [];
    var lista = document.getElementById("listaPedidos");
    if (pedidos.length == 0) {
        lista.textContent = "Todavía no hay pedidos realizados."; } 
    else {
        for (var i = 0; i < pedidos.length; i++) {
        var pedido = pedidos[i];
        var caja = document.createElement("div");
            caja.className = "pedido";
        var titulo = document.createElement("h3");
            titulo.textContent = "Pedido " + (i + 1);
        var nombre = document.createElement("p");
            nombre.textContent = "Cliente: " + pedido.nombre;
         var email = document.createElement("p");
            email.textContent = "Correo: " + pedido.email;
        var producto = document.createElement("p");
            producto.textContent = "Producto: " + pedido.producto;
        var talla = document.createElement("p");
            talla.textContent = "Talla: " + pedido.talla;
        var cantidad = document.createElement("p");
            cantidad.textContent = "Cantidad: " + pedido.cantidad;
        var fecha = document.createElement("p");
            fecha.textContent = "Fecha: " + pedido.fecha;
        var estado = document.createElement("p");
            estado.textContent = "Estado: " + pedido.estado;
            caja.appendChild(titulo);
            caja.appendChild(nombre);
            caja.appendChild(email);
            caja.appendChild(producto);
            caja.appendChild(talla);
            caja.appendChild(cantidad);
            caja.appendChild(fecha);
            caja.appendChild(estado);
            lista.appendChild(caja);
   }
 }
};
