document.getElementById("formPedido").onsubmit = function(event) {
event.preventDefault();
var nombre = document.getElementById("nombre").value;
var email = document.getElementById("email").value;
var producto = document.getElementById("producto").value;
var talla = document.getElementById("talla").value;
var cantidad = document.getElementById("cantidad").value;
var pedido = {
        nombre: nombre,
        email: email,
        producto: producto,
        talla: talla,
        cantidad: cantidad,
        fecha: new Date().toLocaleString(),
        estado: "Pendiente" };
var pedidos = JSON.parse(localStorage.getItem("pedidos")) || [];
pedidos.push(pedido);
localStorage.setItem("pedidos", JSON.stringify(pedidos));
document.getElementById("mensaje").textContent ="¡Pedido realizado!";
document.getElementById("formPedido").reset();
};